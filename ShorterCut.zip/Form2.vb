﻿Imports System.IO

Public Class Form2

    Public Event FileCopied As EventHandler
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the ListView view to Details
        ListViewSearchResults.View = View.Details

        ' Add columns to the ListView
        ListViewSearchResults.Columns.Add("Name", 375, HorizontalAlignment.Left)
        ' Set the ImageList for the ListView
        ListViewSearchResults.SmallImageList = ImageListicons

        ' Set focus to the txtSearch TextBox
        txtSearch.Focus()
        My.Settings.reloadForm = 1
    End Sub

    Private Sub Form2_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        ' Set focus to the txtSearch TextBox
        txtSearch.Focus()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        SearchFiles(txtSearch.Text)
        If ListViewSearchResults.Items.Count > 0 Then
            ListViewSearchResults.Items(0).Selected = True
            ListViewSearchResults.Items(0).EnsureVisible()
        End If
        TextBox2.Text = "Press Enter on selection or double click to add shortcut."
    End Sub

    Private Sub SearchFiles(query As String)
        ListViewSearchResults.Items.Clear()

        Dim startMenuPath As String = Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms)
        Dim lnkFiles() As String

        Try
            lnkFiles = Directory.GetFiles(startMenuPath, "*.lnk", SearchOption.AllDirectories)

            For Each lnkFile As String In lnkFiles
                Dim fileName As String = Path.GetFileNameWithoutExtension(lnkFile)

                If fileName.ToLower().Contains(query.ToLower()) Then
                    ' Create a new ListViewItem
                    Dim item As New ListViewItem(fileName)

                    ' Add the full path as a sub-item
                    item.SubItems.Add(lnkFile)

                    ' Extract and set the icon for the item
                    Dim icon As Icon = Icon.ExtractAssociatedIcon(lnkFile)
                    ImageListicons.Images.Add(fileName, icon)
                    item.ImageKey = fileName

                    ' Add the ListViewItem to the ListView
                    ListViewSearchResults.Items.Add(item)
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Error searching files: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ListViewSearchResults_DoubleClick(sender As Object, e As EventArgs) Handles ListViewSearchResults.DoubleClick
        CopySelectedFile()
    End Sub

    Private Sub ListViewSearchResults_KeyUp(sender As Object, e As KeyEventArgs) Handles ListViewSearchResults.KeyUp
        If e.KeyCode = Keys.Enter Then
            CopySelectedFile()
        End If
    End Sub

    Private Sub CopySelectedFile()
        If ListViewSearchResults.SelectedItems.Count > 0 Then
            Dim selectedItem As ListViewItem = ListViewSearchResults.SelectedItems(0)
            Dim filePath As String = selectedItem.SubItems(1).Text

            If File.Exists(filePath) Then
                Try
                    Dim fileName As String = Path.GetFileName(filePath)
                    Dim destinationPath As String = Path.Combine(My.Settings.folderPath, fileName)
                    File.Copy(filePath, destinationPath, True)
                    txtSearch.Clear()
                    txtSearch.Focus()
                    TextBox2.Text = fileName & " added to " & My.Settings.groupName & "!"
                    Form1.LoadFiles(My.Settings.folderPath)
                    RaiseEvent FileCopied(Me, EventArgs.Empty)
                Catch ex As Exception
                    TextBox2.Text = "Error copying file."
                End Try
            Else
                MessageBox.Show("File does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If

    End Sub
    Private Sub Form2_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        ' Set My.Settings.reloadForm to 0 when Form2 is closed
        My.Settings.reloadForm = 0
    End Sub
End Class
