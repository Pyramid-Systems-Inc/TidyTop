﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        ListViewSearchResults = New ListView()
        ImageListicons = New ImageList(components)
        txtSearch = New TextBox()
        TextBox2 = New TextBox()
        SuspendLayout()
        ' 
        ' ListViewSearchResults
        ' 
        ListViewSearchResults.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        ListViewSearchResults.LargeImageList = ImageListicons
        ListViewSearchResults.Location = New Point(12, 41)
        ListViewSearchResults.Name = "ListViewSearchResults"
        ListViewSearchResults.Size = New Size(374, 237)
        ListViewSearchResults.SmallImageList = ImageListicons
        ListViewSearchResults.TabIndex = 0
        ListViewSearchResults.UseCompatibleStateImageBehavior = False
        ' 
        ' ImageListicons
        ' 
        ImageListicons.ColorDepth = ColorDepth.Depth32Bit
        ImageListicons.ImageSize = New Size(16, 16)
        ImageListicons.TransparentColor = Color.Transparent
        ' 
        ' txtSearch
        ' 
        txtSearch.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        txtSearch.Location = New Point(12, 12)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(373, 23)
        txtSearch.TabIndex = 1
        ' 
        ' TextBox2
        ' 
        TextBox2.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox2.Location = New Point(12, 284)
        TextBox2.Name = "TextBox2"
        TextBox2.ReadOnly = True
        TextBox2.Size = New Size(374, 23)
        TextBox2.TabIndex = 2
        TextBox2.TabStop = False
        TextBox2.Text = "Search shortcuts from the Start Menu directory"
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ControlLight
        ClientSize = New Size(396, 316)
        Controls.Add(TextBox2)
        Controls.Add(txtSearch)
        Controls.Add(ListViewSearchResults)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form2"
        Opacity = 0.97R
        ShowInTaskbar = False
        StartPosition = FormStartPosition.CenterScreen
        Text = "Quick-Add Shortcuts"
        TopMost = True
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ListViewSearchResults As ListView
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents ImageListicons As ImageList
End Class
