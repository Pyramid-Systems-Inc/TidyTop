﻿Imports System.IO
Imports Newtonsoft.Json

Public Class Form1

    Private Class Settings
        Public Property WindowWidth As Integer
        Public Property WindowHeight As Integer
        Public Property FolderPath As String
        Public Property GroupName As String
        Public Property ReloadForm As String
        Public Property DefaultPath As String
        Public Property UserSaved As String
        Public Property BackColor As Color

    End Class

    Private WithEvents timerUpdateListView As New Timer()

    Private Sub timerUpdateListView_Tick(sender As Object, e As EventArgs) Handles timerUpdateListView.Tick
        ' Call the method to load files
        If My.Settings.reloadForm = 1 Then
            LoadFiles(My.Settings.folderPath)
        End If
    End Sub
    Public Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set up the form when it loads
        Try
            ' Check if the application was opened with a command-line argument
            If Environment.GetCommandLineArgs().Length > 1 Then
                ' Get the filename from command-line arguments
                Dim filePath As String = Environment.GetCommandLineArgs()(1)

                ' Check if the file has the .stcrs extension
                If Path.GetExtension(filePath).ToLower() = ".stcrs" AndAlso File.Exists(filePath) Then
                    ' Load settings from the .stcrs file
                    ImportSettings(filePath)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error loading settings: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If My.Settings.userSaved = 0 Then
            Label1.Visible = True
            Label2.Visible = True
            Label3.Visible = True
            Label4.Visible = True
            Label5.Visible = True
            LinkLabel1.Visible = True
        End If
        ImageListicons.ImageSize = New Size(38, 38)
        LoadFiles(My.Settings.folderPath)
        ListViewFiles.AllowDrop = True
        timerUpdateListView.Interval = 2000 ' 2 seconds
        timerUpdateListView.Start()
        textlabel.Text = My.Settings.groupName

        If My.Settings.userSaved = 1 Then
            Label1.Visible = False
            Label1.Visible = False
            Label3.Visible = False
            Label4.Visible = False
            Label5.Visible = False
            LinkLabel1.Visible = False
            Me.Refresh()
        End If

        ' Set the background color of Form1 to bgColor
        Me.BackColor = My.Settings.backColor
        ListViewFiles.BackColor = My.Settings.backColor
        btnTest.BackColor = My.Settings.backColor


        ' Darken the color for Panel1 and textlabel
        Dim darkenColor As Color = DarkenColorFun(My.Settings.backColor, 0.7)

        ' Apply the darkened color to Panel1 and textlabel
        Panel1.BackColor = darkenColor
        textlabel.BackColor = darkenColor
        btnlist.BackColor = darkenColor
        btnSettings.BackColor = darkenColor

        'Update text label
        textlabel.Text = My.Settings.groupName

        'Set Window size
        Me.Size = New Size(My.Settings.WindowWidth, My.Settings.WindowHeight)

        'Reload the list
        LoadFiles(My.Settings.folderPath)
        ListViewFiles.Focus()
    End Sub

    Private Sub ImportSettingsFromFile(filePath As String)
        Try
            ' Check if the file has the .stcrs extension
            If Path.GetExtension(filePath).ToLower() = ".stcrs" Then
                ' Proceed with importing settings
                ImportSettings(filePath)
            Else
                MessageBox.Show("Invalid file format. Please select a .stcrs backup file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error importing settings: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub OpenBackupFile(filePath As String)
        Try
            ' Check if the file has the .stcrs extension
            If Path.GetExtension(filePath).ToLower() = ".stcrs" Then
                ' Proceed with opening the backup file
                ' You can call the appropriate method to load settings from the backup file
                ImportSettings(filePath)
            Else
                MessageBox.Show("Invalid file format. Please select a .stcrs backup file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error opening backup file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub ListViewFiles_DragEnter(sender As Object, e As DragEventArgs) Handles ListViewFiles.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub ListViewFiles_DragDrop(sender As Object, e As DragEventArgs) Handles ListViewFiles.DragDrop
        If My.Settings.folderPath = My.Settings.defaultpath Then
            MessageBox.Show("Create a group before adding shortcuts.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim files As String() = CType(e.Data.GetData(DataFormats.FileDrop), String())
            If files IsNot Nothing AndAlso files.Length > 0 Then
                For Each filePath As String In files
                    If Path.GetExtension(filePath).ToLower() = ".lnk" Then
                        ' Proceed with .lnk file handling
                        Try
                            Dim fileName As String = Path.GetFileName(filePath)
                            Dim destinationPath As String = Path.Combine(My.Settings.folderPath, fileName)
                            File.Copy(filePath, destinationPath, True)
                            ' Delete the source file after copying?
                            ' File.Delete(filePath)
                        Catch ex As Exception
                            MessageBox.Show("Error copying file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    Else
                        ' Create shortcut to the file on the desktop
                        Dim desktopPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
                        Dim shortcutPath As String = Path.Combine(desktopPath, Path.GetFileName(filePath) & ".lnk")

                        Try
                            ' Create shortcut
                            CreateShortcut(filePath, shortcutPath)

                            ' Copy the shortcut to the destination path
                            Dim destinationPath As String = Path.Combine(My.Settings.folderPath, Path.GetFileName(shortcutPath))
                            File.Copy(shortcutPath, destinationPath, True)

                            ' Delete the shortcut from the desktop after copying.
                            File.Delete(shortcutPath)
                        Catch ex As Exception
                            MessageBox.Show("Error creating shortcut or copying file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                Next
            End If
        End If

        ' Load files after dropping
        LoadFiles(My.Settings.folderPath)
    End Sub

    Private Sub CreateShortcut(targetPath As String, shortcutPath As String)
        Try
            Dim shell As Object = CreateObject("WScript.Shell")
            Dim shortcut As Object = shell.CreateShortcut(shortcutPath)

            ' Extract the first letter of the filename
            Dim firstLetter As Char = Path.GetFileNameWithoutExtension(targetPath)(0)

            ' Construct the path to the icon file based on the first letter
            Dim iconPath As String = Path.Combine("C:\ShorterCut\appdata\Icons", firstLetter.ToString().ToUpper(), "favicon.ico")

            ' Set the icon path in the shortcut
            If File.Exists(iconPath) Then
                shortcut.IconLocation = iconPath
            End If

            ' Set other properties of the shortcut
            shortcut.TargetPath = targetPath
            shortcut.Save()
        Catch ex As Exception
            Throw New Exception("Error creating shortcut: " & ex.Message)
        End Try
    End Sub


    Private Sub ListViewFiles_KeyDown(sender As Object, e As KeyEventArgs) Handles ListViewFiles.KeyDown
        If e.KeyCode = Keys.Delete Then
            If ListViewFiles.SelectedItems.Count > 0 Then
                Dim selectedItem As ListViewItem = ListViewFiles.SelectedItems(0)
                Dim filePath As String = Path.Combine(My.Settings.folderPath, selectedItem.Text & ".lnk")

                Try
                    File.Delete(filePath)
                    ListViewFiles.Items.Remove(selectedItem)
                    MessageBox.Show("Shortcut removed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                    MessageBox.Show("Error removing file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End If
    End Sub
    Private Sub ListViewFiles_MouseClick(sender As Object, e As MouseEventArgs) Handles ListViewFiles.MouseClick
        Try
            ' Check if the user has clicked the item with the primary mouse button
            If e.Button = MouseButtons.Left AndAlso ListViewFiles.SelectedItems.Count > 0 Then
                ' Get the selected item in the ListView
                Dim selectedItem As ListViewItem = ListViewFiles.SelectedItems(0)
                ' Get the file name from the selected item
                Dim fileName As String = selectedItem.Text
                ' Construct the full path of the selected file
                Dim filePath As String = Path.Combine(My.Settings.folderPath, fileName & ".lnk")
                ' Check if the file exists
                If File.Exists(filePath) Then
                    ' Get the target path from the shortcut file
                    Dim targetPath As String = GetShortcutTarget(filePath)
                    ' Open the target file with the default application in Windows
                    If Not String.IsNullOrEmpty(targetPath) Then
                        Dim RetVal
                        RetVal = Shell(targetPath, 1)
                        Me.Close()
                    Else
                        MessageBox.Show("Failed to retrieve the target path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("Shortcut file not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
            textlabel.Text = My.Settings.groupName
        Catch
            MessageBox.Show("Target is not an application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub LoadFiles(folderPath As String)
        ' Clear existing items from the ListView
        ListViewFiles.Items.Clear()
        ImageListicons.Images.Clear()

        Try
            ' Get all shortcut files in the folder
            Dim shortcutFiles As String() = Directory.GetFiles(folderPath, "*.lnk")

            ' Add files to the ListView
            For Each shortcutFile As String In shortcutFiles
                ' Get the target path from the shortcut file
                Dim targetPath As String = GetShortcutTarget(shortcutFile)

                If Not String.IsNullOrEmpty(targetPath) AndAlso File.Exists(targetPath) Then
                    ' Create a new ListViewItem with the file name
                    Dim fileName As String = Path.GetFileNameWithoutExtension(shortcutFile)
                    Dim item As New ListViewItem(fileName)

                    ' Get the icon associated with the target file
                    Dim icon As Icon = Icon.ExtractAssociatedIcon(targetPath)

                    ' Add the icon to the ImageList
                    If icon IsNot Nothing Then
                        ImageListicons.Images.Add(fileName, icon)
                        item.ImageKey = fileName
                    End If

                    ' Add the ListViewItem to the ListView
                    ListViewFiles.Items.Add(item)
                End If
            Next
        Catch ex As Exception
            ' Handle exceptions, if any
            MessageBox.Show("Error loading files: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function GetShortcutTarget(shortcutPath As String) As String
        Dim targetPath As String = Nothing

        Try
            Dim shell As Object = CreateObject("WScript.Shell")
            Dim shortcut As Object = shell.CreateShortcut(shortcutPath)
            targetPath = shortcut.TargetPath
        Catch ex As Exception
            MessageBox.Show("Error extracting target path from shortcut: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return targetPath
    End Function
    Private Sub btnSettings_Click(sender As Object, e As EventArgs) Handles btnSettings.Click
        My.Settings.userSaved = 1
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        LinkLabel1.Visible = False
        Me.Refresh()
        Dim form3 As New Form3()
        form3.Show()
    End Sub
    Public Sub ColorPicker()
        ' Open color dialog to choose background color
        Dim colorDialog As New ColorDialog()
        colorDialog.Color = My.Settings.backColor ' Set initial color to saved bgColor setting

        ' Show the color dialog
        If colorDialog.ShowDialog() = DialogResult.OK Then
            ' Save the selected color to the bgColor setting
            My.Settings.backColor = colorDialog.Color
            My.Settings.Save() ' Save the settings

            ' Set the background color of Form1 to bgColor
            Me.BackColor = My.Settings.backColor
            ListViewFiles.BackColor = My.Settings.backColor
            btnTest.BackColor = My.Settings.backColor


            ' Darken the color for Panel1 and textlabel
            Dim darkenColor As Color = DarkenColorFun(My.Settings.backColor, 0.7)

            ' Apply the darkened color to Panel1 and textlabel
            Panel1.BackColor = darkenColor
            textlabel.BackColor = darkenColor
            btnlist.BackColor = darkenColor
            btnSettings.BackColor = darkenColor

            'Update text label
            textlabel.Text = My.Settings.groupName

            'Reload the list
            LoadFiles(My.Settings.folderPath)
            ListViewFiles.Focus()
        End If
    End Sub
    ' Function to darken a color by a percentage
    Private Function DarkenColorFun(ByVal color As Color, ByVal percent As Double) As Color
        Dim factor As Double = 1 - percent
        Dim r As Integer = CInt(Math.Round(color.R * factor))
        Dim g As Integer = CInt(Math.Round(color.G * factor))
        Dim b As Integer = CInt(Math.Round(color.B * factor))
        Return Color.FromArgb(r, g, b)
    End Function
    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnlist.Click
        Try
            ' Run the shell:AppsFolder command
            Process.Start("explorer.exe", "shell:AppsFolder")
        Catch ex As Exception
            ' Handle any exceptions that might occur
            MessageBox.Show("Error opening AppsFolder: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        ListViewFiles.Focus()
    End Sub
    Private Sub btnreset_Click(sender As Object, e As EventArgs)
        Reset()
    End Sub
    Public Sub Reset()
        My.Settings.Reset()
        ' Create and display a new instance of Form1
        Dim newForm1 As New Form1()
        newForm1.Show()
        ListViewFiles.Focus()
    End Sub
    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        ListViewFiles.Focus()
        If My.Settings.folderPath = My.Settings.defaultpath Then
            MessageBox.Show("Create or open a Group before adding shortcuts.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Dim form2 As New Form2
        form2.Show()
    End Sub
    Private Sub Panel1_DoubleClick(sender As Object, e As EventArgs) Handles Panel1.DoubleClick
        ColorPicker()
    End Sub
    Private Sub textlabel_DoubleClick(sender As Object, e As EventArgs) Handles textlabel.DoubleClick
        ColorPicker()
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        ' Define the URL you want to open
        Dim url As String = "https://github.com/escardel/shortercut"

        ' Open the URL in the default web browser
        Try
            Dim psi As New ProcessStartInfo
            psi.UseShellExecute = True
            psi.FileName = url
            Process.Start(psi)
        Catch ex As Exception
            MessageBox.Show("Error opening link: " & ex.Message)
        End Try
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        My.Settings.WindowWidth = Me.Width
        My.Settings.WindowHeight = Me.Height
        ' Prompt user to save backup file
        My.Settings.Save()
        If textlabel.Text <> "ShorterCut" Then
            ExportSettings()
        End If
        My.Settings.Reset()
    End Sub

    Public Sub ExportSettings()
        Try
            ' Define the directory where the backup file will be stored
            Dim backupDirectory As String = Path.Combine(My.Settings.defaultpath, My.Settings.groupName)

            ' Ensure that the backup directory exists, create it if it doesn't
            If Not Directory.Exists(backupDirectory) Then
                ' If the folder group name does not exist in the default path, exit the subroutine
                'MessageBox.Show("The folder group does not exist. Settings were not exported.", "Export Settings", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Define the backup file path (named after group name with the .stcrs extension)
            Dim backupFilePath As String = Path.Combine(backupDirectory, My.Settings.groupName & ".stcrs")

            ' Create a Settings object and populate its properties
            Dim settings As New Settings()
            settings.WindowWidth = My.Settings.WindowWidth
            settings.WindowHeight = My.Settings.WindowHeight
            settings.FolderPath = My.Settings.folderPath
            settings.GroupName = My.Settings.groupName
            settings.ReloadForm = My.Settings.reloadForm
            settings.DefaultPath = My.Settings.defaultpath
            settings.UserSaved = My.Settings.userSaved
            settings.BackColor = My.Settings.backColor

            ' Serialize the Settings object to JSON
            Dim json As String = JsonConvert.SerializeObject(settings)

            ' Write JSON to the backup file
            File.WriteAllText(backupFilePath, json)

            ' Create a shortcut to the backup file on the desktop
            Dim shortcutPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), My.Settings.groupName & ".lnk")
            CreateShortcut(backupFilePath, shortcutPath)

            'MessageBox.Show("Settings exported successfully to: " & backupFilePath, "Export Settings", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error exporting settings: " & ex.Message, "Export Settings Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub




    Private Sub ImportSettings(backupFilePath As String)
        Try
            ' Read JSON from the backup file
            Dim json As String = File.ReadAllText(backupFilePath)

            ' Deserialize JSON to a Settings object
            Dim settings As Settings = JsonConvert.DeserializeObject(Of Settings)(json)

            ' Load settings into My.Settings properties
            My.Settings.WindowWidth = settings.WindowWidth
            My.Settings.WindowHeight = settings.WindowHeight
            My.Settings.folderPath = settings.FolderPath
            My.Settings.groupName = settings.GroupName
            My.Settings.reloadForm = settings.ReloadForm
            My.Settings.defaultpath = settings.DefaultPath
            My.Settings.userSaved = settings.UserSaved
            My.Settings.backColor = settings.BackColor

            'MessageBox.Show("Settings imported successfully.", "Import Settings", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error importing settings: " & ex.Message, "Import Settings Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


End Class
