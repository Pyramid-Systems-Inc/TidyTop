﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        ListViewFiles = New ListView()
        ImageListicons = New ImageList(components)
        btnSettings = New Button()
        Panel1 = New Panel()
        btnlist = New Button()
        textlabel = New TextBox()
        btnTest = New Button()
        ContextMenuStrip1 = New ContextMenuStrip(components)
        ToolTip1 = New ToolTip(components)
        LinkLabel1 = New LinkLabel()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' ListViewFiles
        ' 
        ListViewFiles.Activation = ItemActivation.OneClick
        ListViewFiles.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        ListViewFiles.BackColor = Color.FromArgb(CByte(222), CByte(222), CByte(222))
        ListViewFiles.BorderStyle = BorderStyle.None
        ListViewFiles.HotTracking = True
        ListViewFiles.HoverSelection = True
        ListViewFiles.LargeImageList = ImageListicons
        ListViewFiles.Location = New Point(4, 15)
        ListViewFiles.Margin = New Padding(3, 20, 3, 20)
        ListViewFiles.MultiSelect = False
        ListViewFiles.Name = "ListViewFiles"
        ListViewFiles.Scrollable = False
        ListViewFiles.Size = New Size(410, 318)
        ListViewFiles.TabIndex = 0
        ListViewFiles.UseCompatibleStateImageBehavior = False
        ' 
        ' ImageListicons
        ' 
        ImageListicons.ColorDepth = ColorDepth.Depth32Bit
        ImageListicons.ImageSize = New Size(16, 16)
        ImageListicons.TransparentColor = Color.Transparent
        ' 
        ' btnSettings
        ' 
        btnSettings.BackColor = Color.DimGray
        btnSettings.Cursor = Cursors.Hand
        btnSettings.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSettings.ForeColor = Color.White
        btnSettings.Location = New Point(17, 10)
        btnSettings.Name = "btnSettings"
        btnSettings.Size = New Size(25, 25)
        btnSettings.TabIndex = 1
        btnSettings.Text = "☰"
        ToolTip1.SetToolTip(btnSettings, "Group Manager")
        btnSettings.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Panel1.Controls.Add(btnlist)
        Panel1.Controls.Add(textlabel)
        Panel1.Controls.Add(btnSettings)
        Panel1.Cursor = Cursors.Help
        Panel1.Location = New Point(-9, 334)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(434, 55)
        Panel1.TabIndex = 2
        ToolTip1.SetToolTip(Panel1, "Double click to change color")
        ' 
        ' btnlist
        ' 
        btnlist.BackColor = Color.DimGray
        btnlist.Cursor = Cursors.Hand
        btnlist.Font = New Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnlist.ForeColor = Color.White
        btnlist.ImageAlign = ContentAlignment.TopCenter
        btnlist.Location = New Point(46, 10)
        btnlist.Name = "btnlist"
        btnlist.Size = New Size(25, 25)
        btnlist.TabIndex = 3
        btnlist.Text = "◯"
        ToolTip1.SetToolTip(btnlist, "Show All Installed Apps")
        btnlist.UseVisualStyleBackColor = False
        ' 
        ' textlabel
        ' 
        textlabel.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        textlabel.BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        textlabel.BorderStyle = BorderStyle.None
        textlabel.Cursor = Cursors.Help
        textlabel.Font = New Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        textlabel.ForeColor = SystemColors.Window
        textlabel.Location = New Point(234, 8)
        textlabel.Margin = New Padding(7)
        textlabel.Multiline = True
        textlabel.Name = "textlabel"
        textlabel.ReadOnly = True
        textlabel.ShortcutsEnabled = False
        textlabel.Size = New Size(178, 39)
        textlabel.TabIndex = 5
        textlabel.TabStop = False
        textlabel.Text = "ShorterCut"
        textlabel.TextAlign = HorizontalAlignment.Right
        ToolTip1.SetToolTip(textlabel, "Double click to change color")
        ' 
        ' btnTest
        ' 
        btnTest.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnTest.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        btnTest.Cursor = Cursors.Hand
        btnTest.Font = New Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnTest.ForeColor = Color.White
        btnTest.Location = New Point(382, 302)
        btnTest.Margin = New Padding(0)
        btnTest.Name = "btnTest"
        btnTest.Size = New Size(25, 25)
        btnTest.TabIndex = 4
        btnTest.Text = "+"
        ToolTip1.SetToolTip(btnTest, "Quick Add from Start Menu")
        btnTest.UseVisualStyleBackColor = False
        ' 
        ' ContextMenuStrip1
        ' 
        ContextMenuStrip1.Name = "ContextMenuStrip1"
        ContextMenuStrip1.Size = New Size(61, 4)
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Location = New Point(16, 15)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(73, 15)
        LinkLabel1.TabIndex = 7
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Github Repo"
        ToolTip1.SetToolTip(LinkLabel1, "github")
        LinkLabel1.Visible = False
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        Label1.AutoSize = True
        Label1.Location = New Point(33, 307)
        Label1.Name = "Label1"
        Label1.Size = New Size(272, 15)
        Label1.TabIndex = 5
        Label1.Text = " Open Group Manager to create or remove Groups"
        Label1.Visible = False
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(8, 295)
        Label2.Name = "Label2"
        Label2.Size = New Size(42, 32)
        Label2.TabIndex = 6
        Label2.Text = "⬐ "
        Label2.Visible = False
        ' 
        ' Label3
        ' 
        Label3.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Label3.AutoSize = True
        Label3.Location = New Point(298, 277)
        Label3.Name = "Label3"
        Label3.Size = New Size(82, 15)
        Label3.TabIndex = 8
        Label3.Text = "Add Shortcuts"
        Label3.Visible = False
        ' 
        ' Label4
        ' 
        Label4.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(373, 270)
        Label4.Name = "Label4"
        Label4.Size = New Size(34, 32)
        Label4.TabIndex = 9
        Label4.Text = "↴"
        Label4.Visible = False
        ' 
        ' Label5
        ' 
        Label5.Anchor = AnchorStyles.None
        Label5.AutoSize = True
        Label5.ForeColor = SystemColors.ControlDark
        Label5.Location = New Point(150, 164)
        Label5.Name = "Label5"
        Label5.Size = New Size(114, 15)
        Label5.TabIndex = 10
        Label5.Text = "Drag and  Drop Area"
        Label5.Visible = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(222), CByte(222), CByte(222))
        ClientSize = New Size(414, 378)
        Controls.Add(Label5)
        Controls.Add(Label3)
        Controls.Add(Label4)
        Controls.Add(LinkLabel1)
        Controls.Add(Label1)
        Controls.Add(Label2)
        Controls.Add(btnTest)
        Controls.Add(Panel1)
        Controls.Add(ListViewFiles)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimumSize = New Size(285, 150)
        Name = "Form1"
        Opacity = 0.97R
        StartPosition = FormStartPosition.CenterScreen
        Text = "ShorterCut"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ListViewFiles As ListView
    Friend WithEvents ImageListicons As ImageList
    Friend WithEvents btnSettings As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents textlabel As TextBox
    Friend WithEvents btnlist As Button
    Friend WithEvents btnTest As Button
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label

End Class
