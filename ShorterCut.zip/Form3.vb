﻿Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form3

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Save input from txtbox1 as my.settings.group
        My.Settings.groupName = TextBox1.Text.Trim()
        Dim folderPath As String = Path.Combine(My.Settings.defaultpath, My.Settings.groupName)

        ' Check if the folder already exists
        If Directory.Exists(folderPath) Then
            MessageBox.Show("Group already exists.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return ' Exit the subroutine if the folder already exists
        End If

        ' Create the folder if it doesn't exist
        Directory.CreateDirectory(folderPath)
        My.Settings.folderPath = folderPath
        Form1.textlabel.Text = My.Settings.groupName
        LoadItemsToListBox()
        If My.Settings.groupName <> "ShorterCut" Then
            Form1.ExportSettings()
            MessageBox.Show("Group saved to Desktop.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        Me.Close()
    End Sub

    Private Sub Form3_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' Call the subroutine on Form1
        ' Form1.ColorPicker()

    End Sub
    Private folderPath As String

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the folder path
        folderPath = Path.Combine(My.Settings.defaultpath, My.Settings.folderPath)
        ' Load items into ListBox1
        LoadItemsToListBox()
    End Sub

    Private Sub LoadItemsToListBox()
        ' Clear existing items
        ListBox1.Items.Clear()

        Try
            ' Get all directories in the default path
            Dim directories As String() = Directory.GetDirectories(My.Settings.defaultpath)

            ' Add directory names to ListBox1 excluding "icons" folders
            For Each directory As String In directories
                If Not directory.EndsWith("icons", StringComparison.OrdinalIgnoreCase) Then
                    ListBox1.Items.Add(Path.GetFileName(directory))
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Error loading items: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' Check if an item is selected
        If ListBox1.SelectedIndex >= 0 Then
            ' Get the selected folder name
            Dim folderName As String = ListBox1.SelectedItem.ToString()

            ' Construct the full path of the folder to delete
            Dim folderPath As String = Path.Combine(My.Settings.defaultpath, folderName)

            ' Ask for confirmation before deleting
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete '" & folderName & "'?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                Try
                    ' Check if the folder exists
                    If Directory.Exists(folderPath) Then
                        ' Delete the folder
                        Directory.Delete(folderPath, True)

                        ' Delete the corresponding shortcut file on the desktop
                        Dim desktopShortcutPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), folderName & ".lnk")
                        If File.Exists(desktopShortcutPath) Then
                            File.Delete(desktopShortcutPath)
                        End If

                        ' Close the form if the deleted folder is the currently selected group
                        If Form1.textlabel.Text.ToString() = folderName Then
                            MessageBox.Show("You are deleting an open Group. Application will close." & folderPath, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            Me.Close()
                            Form1.Close()
                        End If

                        ' Update the ListBox after deleting
                        LoadItemsToListBox()
                    Else
                        MessageBox.Show("Group does not exist: " & folderPath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MessageBox.Show("Error deleting group: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        Else
            MessageBox.Show("Please select a group to delete.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


End Class
